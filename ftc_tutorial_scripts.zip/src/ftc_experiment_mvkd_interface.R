#############################
### specify the following three variables
#############################
features<-1:10 # <<<<<< specify
sample.size<-2500 # <<<<<< specify either 500, 1000, 1500 or 2500
cross.validation<-"no" # <<<<<< specify either "yes" or "no"

##############################
## 1: YuleI
## 2: TTR
## 3: Honore
## 4: AverageWNperMessage
## 5: Unusual word ratio
## 6: AverageCNperMessage
## 7: Digit_ratio_to_N * 1000
## 8: Average_NC_per_word
## 9: Punctuations_per_NC
## 10: Special_characters_per_NC
##############################

source("./tools/kden_mvlr.R")
source("./tools/calibrate.R")
source("./tools/plot_tippett.R")
source("./tools/precision_only_ds_comparison.R")
source("./tools/calc_eer.R")
source("./tools/plot_ece_interface.R")
source("./tools/plot_ece.R")

collapsed.features<-paste(features, sep="",collapse="")

############ non cross-validated experiment
############ non cross-validated experiment
############ non cross-validated experiment
############ non cross-validated experiment
if (cross.validation == "no") {
    cat(paste("features:", paste(features, sep="",collapse=" "), sep=" "), "\n")
    cat(paste("sample size: ", sample.size, " words", sep=""), "\n")
    cat(paste("cross validation: ", cross.validation, sep=""), "\n")

    background.db.file<-paste("../database/background_features_", sample.size, ".txt", sep="")
    # background.db.file<-paste("../database/test_features_", sample.size, ".txt", sep="")
    
    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## 
    ## Test database: score calculation
    test.db.file<-paste("../database/test_features_", sample.size, ".txt", sep="")
    test.file.name.head<-paste("test_", sample.size, sep="")
    test.sascore.file<-
        paste("../score_dump/", paste(test.file.name.head,
                                      "non_cross_validated_sa_score", "feature", collapsed.features, sep="_"), ".txt", sep="")
    test.dascore.file<-
        paste("../score_dump/", paste(test.file.name.head,
                                      "non_cross_validated_da_score", "feature", collapsed.features, sep="_"), ".txt", sep="")
    cat("...... Calculating scores for Test DB")
    cat(" ......\n")
    x<-non.cross.validated.mvlr.kden.calculation(features,
                                                 test.db.file,
                                                 background.db.file,
                                                 test.sascore.file,
                                                 test.dascore.file)

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## 
    ## Development database: score calculation
    development.db.file<-paste("../database/development_features_", sample.size, ".txt", sep="")
    development.file.name.head<-paste("development_", sample.size, sep="")
    development.sascore.file<-
        paste("../score_dump/", paste(development.file.name.head,
                                      "non_cross_validated_sa_score", "feature", collapsed.features, sep="_"), ".txt", sep="")
    development.dascore.file<-
        paste("../score_dump/", paste(development.file.name.head,
                                      "non_cross_validated_da_score", "feature", collapsed.features, sep="_"), ".txt", sep="")
    cat("...... Calculating scores for Development DB")
    cat(" ......\n")
    x<-non.cross.validated.mvlr.kden.calculation(features,
                                                 development.db.file,
                                                 background.db.file,
                                                 development.sascore.file,
                                                 development.dascore.file)

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## score tippett plot
    cat("...... Drawing Tippett plot for scores (uncalibrated LRs), ")
    score.tippett.plot.file<-
        paste("../figures/", paste(test.file.name.head,
                                   "feature", collapsed.features, "non_cross_validated_score_tippett", sep="_"), ".jpeg", sep="")

    plot.uncalib.tippett.plot(test.sascore.file,
                              test.dascore.file,
                              score.tippett.plot.file
                              )
    cat("Done ......\n")

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## 
    ## EER
    sascores.in<-read.table(test.sascore.file, header=FALSE)
    dascores.in<-read.table(test.dascore.file, header=FALSE)
    eer.file<-paste("../assessment_outcomes/", paste(test.file.name.head,
                                         "feature", collapsed.features, "non_cross_validated_eer", sep="_"), ".txt", sep="")
    sascores<-sascores.in[,2]
    dascores<-c(dascores.in[,3], dascores.in[,4])
    cat("...... Calculating EER, ")

    eer<-calc.eer(sascores, dascores, eer.file)
    cat("Done ......\n")
    cat(paste("...... eer: ", eer, "\n", sep=""))

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## CLLR
    test.salr.file<-
        paste("../lr_dump/", paste(test.file.name.head,
                                   "non_cross_validated_sa_lr", "feature", collapsed.features, sep="_"), ".txt", sep="")
    test.dalr.file<-
        paste("../lr_dump/", paste(test.file.name.head,
                                   "non_cross_validated_da_lr", "feature", collapsed.features, sep="_"), ".txt", sep="")
    calib.test.cllr.file<-
        paste("../assessment_outcomes/", paste(test.file.name.head,
                                   "feature", collapsed.features, "non_cross_validated_cllr", sep="_"), ".txt", sep="")
    cat("...... Calibrating scores and calculating Cllr, ")

    cllr<-calibrate(test.sascore.file,
                    test.dascore.file,
                    development.sascore.file,
                    development.dascore.file,
                    test.salr.file,
                    test.dalr.file,
                    calib.test.cllr.file)
    cat("Done ......\n")
    cat(paste("...... cllr:", cllr[1], "\n", sep=" "))
    cat(paste("...... cllr_min:", cllr[2], "\n", sep=" "))
    cat(paste("...... cllr_cal:", cllr[3], "\n", sep=" "))

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## calib tippett plot
    cat("...... Drawing Tippett plot for (calibrated) LRs, ")
    calib.tippett.plot.file<-
        paste("../figures/", paste(test.file.name.head,
                                   "feature", collapsed.features, "non_cross_validated_lr_tippett", sep="_"), ".jpeg", sep="")

    plot.calib.tippett.plot(test.salr.file,
                            test.dalr.file,
                            calib.tippett.plot.file
                            )
    cat("Done ......\n")

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## uncalib ad calib tippett plot
    uncalib.calib.tippett.plot.file<-
        paste("../figures/", paste(test.file.name.head,
                                   "feature", collapsed.features, "non_cross_validated_score_lr_tippett", sep="_"),
              ".jpeg", sep="")
    cat("...... Drawing Tippett plot for scores and LRs, ")

    plot.uncalib.calib.tippett.plot(test.sascore.file,
                                    test.dascore.file,
                                    test.salr.file,
                                    test.dalr.file,
                                    uncalib.calib.tippett.plot.file
                                    )
    cat("Done ......\n")

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## ECE
    ece.plot.file<-
        paste("../figures/", paste(test.file.name.head,
                                   "feature", collapsed.features, "non_cross_validated_lr_ece_plot", sep="_"), ".jpeg", sep="")
    cat("...... Drawing ECE plot for LRs, ")

    x<-calc.plot.ece(test.salr.file,
                     test.dalr.file,
                     ece.plot.file
                     )
    cat("Done ......\n")

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## 95% CI
    # ci.hist.figure.file<-
    #    paste("../figures/", paste(test.file.name.head,
    #                               "feature", collapsed.features, "non_cross_validated_ci", "histgram", sep="_"), ".jpeg", sep="")
    # calib.tippett.plot.with.ci.file<-
    #    paste("../figures/", paste(test.file.name.head,
    #                               "feature", collapsed.features, "non_cross_validated_lr_tippett_with_ci", sep="_"), ".jpeg", sep="")
    # calib.test.ci.file<-
    #    paste("../assessment_outcomes/", paste(test.file.name.head,
    #                               "feature", collapsed.features, "non_cross_validated_ci", sep="_"), ".txt", sep="")
    # cat("...... Calculating 95% CI, ")

    # ci<-calculate.ci(test.salr.file,
    #                 test.dalr.file,
    #                 calib.tippett.plot.with.ci.file,
    #                                    #ci.hist.figure.file,
    #                 calib.test.ci.file
    #                 )
    # cat("Done ......\n")
    # cat(paste("...... 95%CI:", ci, "\n", sep=" "))

    rm(list=ls(all=TRUE))
    
############ Cross-validated experiment
############ Cross-validated experiment
############ Cross-validated experiment
############ Cross-validated experiment
} else if(cross.validation == "yes") {
    cat(paste("features:", paste(features, sep="",collapse=" "), sep=" "), "\n")
    cat(paste("sample size: ", sample.size, " words", sep=""), "\n")
    cat(paste("cross validation: ", cross.validation, sep=""), "\n")
    
    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## 
    ## Test database: score calculation
    test.db.file<-paste("../database/all_features_", sample.size, ".txt", sep="")
    test.file.name.head<-paste("test_", sample.size, sep="")
    test.sascore.file<-
        paste("../score_dump/", paste(test.file.name.head,
                                      "cross_validated_sa_score", "feature", collapsed.features, sep="_"), ".txt", sep="")
    test.dascore.file<-
        paste("../score_dump/", paste(test.file.name.head,
                                      "cross_validated_da_score", "feature", collapsed.features, sep="_"), ".txt", sep="")
    cat("...... Calculating scores for Test DB")
    cat(" ......\n")
    

    x<-cross.validated.mvlr.kden.calculation(features,
                                             test.db.file,
                                             test.sascore.file,
                                             test.dascore.file)

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## score tippett plot
    cat("...... Drawing Tippett plot for scores (uncalibrated LRs), ")
    score.tippett.plot.file<-
        paste("../figures/", paste(test.file.name.head,
                                   "feature", collapsed.features, "cross_validated_score_tippett", sep="_"), ".jpeg", sep="")

    plot.uncalib.tippett.plot(test.sascore.file,
                              test.dascore.file,
                              score.tippett.plot.file
                              )
    cat("Done ......\n")

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## 
    ## EER
    sascores.in<-read.table(test.sascore.file, header=FALSE)
    dascores.in<-read.table(test.dascore.file, header=FALSE)
    eer.file<-paste("../assessment_outcomes/", paste(test.file.name.head,
                                         "feature", collapsed.features, "cross_validated_eer", sep="_"), ".txt", sep="")
    sascores<-sascores.in[,2]
    dascores<-c(dascores.in[,3], dascores.in[,4])
    cat("...... Calculating EER, ")

    eer<-calc.eer(sascores, dascores, eer.file)
    cat("Done ......\n")
    cat(paste("...... eer: ", eer, "\n", sep=""))

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## CLLR
    test.salr.file<-
        paste("../lr_dump/", paste(test.file.name.head,
                                   "cross_validated_sa_lr", "feature", collapsed.features, sep="_"), ".txt", sep="")
    test.dalr.file<-
        paste("../lr_dump/", paste(test.file.name.head,
                                   "cross_validated_da_lr", "feature", collapsed.features, sep="_"), ".txt", sep="")
    calib.test.cllr.file<-
        paste("../assessment_outcomes/", paste(test.file.name.head,
                                   "feature", collapsed.features, "cross_validated_cllr", sep="_"), ".txt", sep="")
    cat("...... Calibrating scores and calculating Cllr")
    cat(" ......\n")

    cllr<-cross.validation.calibrate(test.sascore.file,
                    test.dascore.file,
                    test.salr.file,
                    test.dalr.file,
                    calib.test.cllr.file)

    cat(paste("...... cllr:", cllr[1], "\n", sep=" "))
    cat(paste("...... cllr_min:", cllr[2], "\n", sep=" "))
    cat(paste("...... cllr_cal:", cllr[3], "\n", sep=" "))

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## calib tippett plot
    cat("...... Drawing Tippett plot for (calibrated) LRs, ")
    calib.tippett.plot.file<-
        paste("../figures/", paste(test.file.name.head,
                                   "feature", collapsed.features, "cross_validated_lr_tippett", sep="_"), ".jpeg", sep="")

    plot.calib.tippett.plot(test.salr.file,
                            test.dalr.file,
                            calib.tippett.plot.file
                            )
    cat("Done ......\n")

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## uncalib ad calib tippett plot
    uncalib.calib.tippett.plot.file<-
        paste("../figures/", paste(test.file.name.head,
                                   "feature", collapsed.features, "cross_validated_score_lr_tippett", sep="_"),
              ".jpeg", sep="")
    cat("...... Drawing Tippett plot for scores and LRs, ")

    plot.uncalib.calib.tippett.plot(test.sascore.file,
                                    test.dascore.file,
                                    test.salr.file,
                                    test.dalr.file,
                                    uncalib.calib.tippett.plot.file
                                    )
    cat("Done ......\n")

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## ECE
    ece.plot.file<-
        paste("../figures/", paste(test.file.name.head,
                                   "feature", collapsed.features, "cross_validated_lr_ece_plot", sep="_"), ".jpeg", sep="")
    cat("...... Drawing ECE plot for LRs, ")

    x<-calc.plot.ece(test.salr.file,
                     test.dalr.file,
                     ece.plot.file
                     )
    cat("Done ......\n")

    ## ## ## ## ## ## ## ## ## ## ## ## ## ## ##
    ## 95% CI
    # ci.hist.figure.file<-
    #    paste("../figures/", paste(test.file.name.head,
    #                               "feature", collapsed.features, "cross_validated_ci", "histgram", sep="_"), ".jpeg", sep="")
    # calib.tippett.plot.with.ci.file<-
    #    paste("../figures/", paste(test.file.name.head,
    #                               "feature", collapsed.features, "cross_validated_lr_tippett_with_ci", sep="_"), ".jpeg", sep="")
    # calib.test.ci.file<-
    #    paste("../assessment_outcomes/", paste(test.file.name.head,
    #                                "feature", collapsed.features, "cross_validated_ci", sep="_"), ".txt", sep="")
    # cat("...... Calculating 95% CI, ")
    
    # ci<-calculate.ci(test.salr.file,
    #                 test.dalr.file,
    #                 calib.tippett.plot.with.ci.file,
    #                 # ci.hist.figure.file,
    #                 calib.test.ci.file
    #                 )
    # cat("Done ......\n")
    # cat(paste("...... 95%CI:", ci, "\n", sep=" "))
    
    rm(list=ls(all=TRUE))

} else {print("Please answer either 'yes' or 'no' for validation type!")}

## End of Script
