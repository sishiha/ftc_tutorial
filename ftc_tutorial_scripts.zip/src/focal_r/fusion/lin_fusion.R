lin.fusion <- function(weights,scores) {
  f = t(weights)%*%rbind(scores,matrix(1,1,ncol(scores)))
  
  return(f)

}
