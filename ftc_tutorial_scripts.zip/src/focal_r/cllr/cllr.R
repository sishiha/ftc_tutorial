# cllr(tar.llrs, nontar.llrs)
cllr <- function (tar.llrs, nontar.llrs) { # inputs: loge LRs
  
  c1 <- mean(neglogsigmoid(tar.llrs))/log(2)
  c2 <- mean(neglogsigmoid(-nontar.llrs))/log(2)
  c <- (c1+c2)/2
  return(c) # cllr value
  
}
