options(digits=5)

# inputs cllr.min: loge
cllr.min <- function (tar.scores, nontar.scores) { 
  calibrated.output<-calibrate.set(tar.scores, nontar.scores, method = "raw")   
  optimised.tar.llrs<-log(calibrated.output$LR.cal.ss)
  optimised.nontar.llrs<-log(calibrated.output$LR.cal.ds)
    
  ## inputs of cllr(): loge
  cllr.min.value <- cllr(optimised.tar.llrs, optimised.nontar.llrs)
  return(cllr.min.value)
  
}
