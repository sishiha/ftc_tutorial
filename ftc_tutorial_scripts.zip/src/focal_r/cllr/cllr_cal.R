# input of cllr.cal: loge
cllr.cal <- function (tar.scores, nontar.scores) {
  # input of cllr.cal: loge
  cllr <- cllr(tar.scores, nontar.scores)
  # input of cllr.min: loge
  cllr.min <- cllr.min(tar.scores, nontar.scores)
  cllr.cal <- cllr - cllr.min

  return(cllr.cal)
  
}
