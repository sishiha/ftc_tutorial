cross.validation.calibrate<-function(TSS1,
                    TDS1,
                    ssfilename,
                    dsfilename,
                    filename
                    ) {

    file.sources1 = list.files("./focal_r/cllr",full.names=TRUE, pattern="*.[Rr]$")
    file.sources2 = list.files("./focal_r/fusion",full.names=TRUE, pattern="*.[Rr]$")
    file.sources3 = list.files("./focal_r/utils",full.names=TRUE, pattern="*.[Rr]$")
    sapply(file.sources1,source,.GlobalEnv)
    sapply(file.sources2,source,.GlobalEnv)
    sapply(file.sources3,source,.GlobalEnv)

### test data ###
    datatss1 <- read.table(TSS1,header=FALSE)
    datatds1 <- read.table(TDS1,header=FALSE)

    tss1 <- as.vector(datatss1[,2])
    logetss <- rbind(log(10^tss1))
    
    tds11 <- as.vector(datatds1[,3])
    tds12 <- as.vector(datatds1[,4])

    tds1 = c(tds11, tds12)
    logetds <- rbind(log(10^tds1))

### calculate logistic-regression weights in cross-validation manner
############### 
    length.logetss<-length(logetss)
    length.logetds<-length(logetds)

############### same origin 
    list.cross.validated.target<-NULL

    pb <- txtProgressBar(min = 1, max = length.logetss, style = 3)

    cat("...... Calibrating SA scores")
    cat(" ......\n")
    
    for (i in 1:length.logetss) {
        specific.logetss.lr<-logetss[1,i]
        everything.else.logetss.lrs<-t(as.matrix(logetss[1,-i]))

        w <- train.llr.fusion(everything.else.logetss.lrs,logetds)
        targetf <- lin.fusion(w, as.matrix(specific.logetss.lr))
        list.cross.validated.target<-c(list.cross.validated.target,targetf)
        setTxtProgressBar(pb, i)        
    }

    close(pb)
    
############### same origin end
############### different origin 
    list.cross.validated.non.target<-NULL
    
    pb <- txtProgressBar(min = 1, max = length.logetds, style = 3)

    cat("...... Calibrating DA scores")
    cat(" ......\n")
    
    for (i in 1:length.logetds) {
        specific.logetds.lr<-logetds[1,i]
        everything.else.logetds.lrs<-t(as.matrix(logetds[1,-i]))

        w <- train.llr.fusion(logetss,everything.else.logetds.lrs)
        nontargetf <- lin.fusion(w, as.matrix(specific.logetds.lr))
        list.cross.validated.non.target<-c(list.cross.validated.non.target,nontargetf)
        setTxtProgressBar(pb, i)        
    }

    close(pb)
    
############### different origin end
    log10targetf <- as.vector(log10(exp(list.cross.validated.target)))
    log10nontargetf <- as.vector(log10(exp(list.cross.validated.non.target)))
    
### calculate logistic-regression weights in cross-validation manner end
    write(log10targetf, file=ssfilename, ncolumns = 1)
    write(log10nontargetf, file=dsfilename, ncolumns = 1)

    non.calib.cllr.value <- cllr(logetss,logetds)
    non.calib.cllr.min.value <- cllr.min(logetss,logetds)
    non.calib.cllr.cal.value <- cllr.cal(logetss,logetds)
    non.calib.cllr.min.cal.values <- c(non.calib.cllr.value,
                                       non.calib.cllr.min.value,
                                       non.calib.cllr.cal.value
                                       )

    calib.cllr.value <- cllr(list.cross.validated.target,list.cross.validated.non.target)
    calib.cllr.min.value <- cllr.min(list.cross.validated.target,list.cross.validated.non.target)
    calib.cllr.cal.value <- cllr.cal(list.cross.validated.target,list.cross.validated.non.target)
    calib.cllr.min.cal.values <- c(calib.cllr.value, calib.cllr.min.value, calib.cllr.cal.value)

    title.calib.cllr.min.cal.values<-(rbind(c("before/after_calib", "cllr","cllrmin","cllrcal"),
                                            c("before_calib", non.calib.cllr.min.cal.values),
                                            c("after_calib", calib.cllr.min.cal.values))
    )

    write.table(title.calib.cllr.min.cal.values,file=filename, sep=" ", quote=FALSE,
                row.names = FALSE, col.names = FALSE)

    return(calib.cllr.min.cal.values)
    
    rm(list=ls(all=TRUE))

}

calibrate<-function(TSS1,
                    TDS1,
                    DSS1,
                    DDS1,
                    ssfilename,
                    dsfilename,
                    filename
                    ) {

    file.sources1 = list.files("./focal_r/cllr",full.names=TRUE, pattern="*.[Rr]$")
    file.sources2 = list.files("./focal_r/fusion",full.names=TRUE, pattern="*.[Rr]$")
    file.sources3 = list.files("./focal_r/utils",full.names=TRUE, pattern="*.[Rr]$")
    sapply(file.sources1,source,.GlobalEnv)
    sapply(file.sources2,source,.GlobalEnv)
    sapply(file.sources3,source,.GlobalEnv)

### test data ###
    datatss1 <- read.table(TSS1,header=FALSE)
    datatds1 <- read.table(TDS1,header=FALSE)
    
    tss1 <- as.vector(datatss1[,2])
    logetss <- rbind(log(10^tss1))

    tds11 <- as.vector(datatds1[,3])
    tds12 <- as.vector(datatds1[,4])

    tds1 = c(tds11, tds12)
    logetds <- rbind(log(10^tds1))

### development data ###
    datadss1 <- read.table(DSS1,header=FALSE)
    datadds1 <- read.table(DDS1,header=FALSE)

    dss1 <- as.vector(datadss1[,2])
    logedss <- rbind(log(10^dss1))

    dds11 <- as.vector(datadds1[,3])
    dds12 <- as.vector(datadds1[,4])

    dds1 = c(dds11, dds12)
    logedds <- rbind(log(10^dds1))

### calculate logistic-regression weights
    w <- train.llr.fusion(logedss,logedds)

### convert scores to LRs
    targetf <- lin.fusion(w, logetss)
    nontargetf <- lin.fusion(w, logetds)

    log10targetf <- as.vector(log10(exp(targetf)))
    log10nontargetf <- as.vector(log10(exp(nontargetf)))

    write(log10targetf, file=ssfilename, ncolumns = 1)
    write(log10nontargetf, file=dsfilename, ncolumns = 1)

    non.calib.cllr.value <- cllr(logetss,logetds)
    non.calib.cllr.min.value <- cllr.min(logetss,logetds)
    non.calib.cllr.cal.value <- cllr.cal(logetss,logetds)
    non.calib.cllr.min.cal.values <- c(non.calib.cllr.value,
                                       non.calib.cllr.min.value,
                                       non.calib.cllr.cal.value
                                       )

    calib.cllr.value <- cllr(targetf,nontargetf)
    calib.cllr.min.value <- cllr.min(targetf,nontargetf)
    calib.cllr.cal.value <- cllr.cal(targetf,nontargetf)
    calib.cllr.min.cal.values <- c(calib.cllr.value, calib.cllr.min.value, calib.cllr.cal.value)

    title.calib.cllr.min.cal.values<-(rbind(c("before/after_calib", "cllr","cllrmin","cllrcal"),
                                            c("before_calib", non.calib.cllr.min.cal.values),
                                            c("after_calib", calib.cllr.min.cal.values))
                                  )

    write.table(title.calib.cllr.min.cal.values,file=filename, sep=" ", quote=FALSE,
                row.names = FALSE, col.names = FALSE)

    return(calib.cllr.min.cal.values)

    rm(list=ls(all=TRUE))

}
