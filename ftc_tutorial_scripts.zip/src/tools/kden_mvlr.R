## Created by Shunichi Ishihara (2018)
library(comparison)

cross.validated.mvlr.kden.calculation<-function(parameters,
                                parameter.in.file,
                                sa.out.file.name,
                                da.out.file.name) {

#################################################
#################################################
#################################################
##
## This script was written by Shunichi Ishihara to be
## able to conduct an experiment in non-cross-validated
## manner.
##
#################################################
#################################################
#################################################

    ## convert variables to actual column numbers
    variables<-parameters + 3

    adjusted.variables<-(variables - 3)
    feature.legend<-paste("para", paste(adjusted.variables, sep="", collapse=""), sep="")

    pop <- read.table(parameter.in.file, header=TRUE)
    ## a list of unique author names  
    author.names <- unique(pop$authorindex)
    pop.no.individuals<- length(author.names)
  
########
########
    ## check whether all parameters have the same repetitions
    all.reps<-pop$repetition
    rep.max<-max(pop$repetition)
    rep.min<-min(pop$repetition)
    number.rep.max<-length(which(all.reps == rep.max))
    number.rep.min<-length(which(all.reps == rep.min))

    if (number.rep.max == number.rep.min) {
        number.of.repeat<-max(pop$repetition)
  
    } else {
        stop("all values are not in the same number")
  
    }
########
########

    grouping.variable <- 1

################## Same-author LRs ##################
################## Same-author LRs ##################
################## Same-author LRs ##################
################## Same-author LRs ##################

    SA <- 1 

    ## initialise matrices 
    SALR.den <- c(0)
    SALR.den.tmp <- c(0)

    pb <- txtProgressBar(min = 1, max = pop.no.individuals, style = 3)

    cat("...... SA comparisons")
    cat(" ......\n")
    
    for (SAcomp in 1 : pop.no.individuals) {
#### NOTE ################################
#### NOTE ################################
# sus <- pop[SA:(SA + n), ] # specify n
# how many repetition? If it is x, n should be x - 1
        SAZZ<-(number.of.repeat - 1)
        sus <- pop[SA:(SA + SAZZ), ]
##########################################
##########################################  
  
#### NOTE ################################
#### NOTE ################################
# off <- pop[(SA+n):(SA+m),] # specifiy n and m
# how many repetition? If it is x, n and m should be x and (x * 2) - 1
        SANN<-number.of.repeat
        SAMM<-(number.of.repeat*2)-1
        off <- pop[(SA+SANN):(SA+SAMM),]
##########################################
##########################################

#########################################
#########################################
## Similarity between offender and suspect samples
        control<-two.level.comparison.items(off,variables)
        recovered<-two.level.comparison.items(sus,variables)    

############################### back ground statistics
############################### back ground statistics
## cross-validated background statistics
## x should be the number of repetition - 1
## y should be the number of repetition
## z should be (the number of repetition * 2) - 1
## background.pop<-pop[c(-SS:-(SS+x),-(SS+y):-(SS+z)),]

        xx<-number.of.repeat - 1
        yy<-number.of.repeat
        zz<-(number.of.repeat*2)-1
  
        background.pop<-pop[c(-SA:-(SA+xx),-(SA+yy):-(SA+zz)),]

        # calculate the within and between group co-variances and means for each group
        UC<-two.level.components(background.pop,variables,grouping.variable)

#--------------------------------------------------------------------
        SALR.den.tmp<-suppressWarnings(two.level.density.LR(control,recovered,UC))

        SALR.den <- c(SALR.den,SALR.den.tmp)

#### NOTE ################################
#### NOTE ################################
# SA <- SA + n # specify n
# how many repetition? If it is x, n should be x * 2
        SA <- SA + (number.of.repeat*2)
        setTxtProgressBar(pb, SAcomp)        

  }
    close(pb)

    ## for some reason this has a lenght of one more than it should, with a first element as 0.
    ## patch-up for the moment:
    SALR.den <- SALR.den[-1]
    log10.SALR.den <- log10(as.matrix(SALR.den))

    ## assemble matrix of both LRs with author
    authors <-as.matrix(unique(author.names))
    same.author.den.logLRs <- cbind(authors,log10.SALR.den)

############### END: Same-author LRs ################
############### END: Same-author LRs ################
############### END: Same-author LRs ################
############### END: Same-author LRs ################

############### Different-author LRs ################
############### Different-author LRs ################
############### Different-author LRs ################
############### Different-author LRs ################

    ## Pre-process for DA LRs
    ## first compile matrix of DA author names/indicies for the different author comparisons.
    author.names <- as.matrix(author.names)

    no.author <- length(author.names)
    how.many <- no.author -1

    DA.sus.indicies <- c()
    DA.sus.names <- c()
  
    DA.off.indicies <- c()
    DA.off.names <- c()

    for(i in 1: (no.author - 1)) {

        DA.sus.index.tmp <- rep(i,how.many)
        DA.off.index.tmp <- seq(from= (i+1), to= no.author)

        DA.sus.indicies <- c(DA.sus.indicies,DA.sus.index.tmp)
        DA.off.indicies <- c(DA.off.indicies,DA.off.index.tmp)

        how.many <- how.many - 1

    } 
    
    DA.sus.names <- author.names[DA.sus.indicies]
    DA.off.names <- author.names[DA.off.indicies]

    DA.comps.author.indicies <- cbind(DA.sus.indicies,DA.off.indicies)

    DA.comps.author.names <- cbind(DA.sus.names,DA.off.names)

    da.no.comparisons<- nrow(DA.comps.author.names) * 4
    current.da.comparison<-0
    ## END: Pre-process for DA LRs

################################# PARTITION 1 #############################
################################# PARTITION 1 #############################
## authorA-1
## authorA-2
## authorB-1
## authorB-2
## PARTITION 1: AuthorA-1 vs. AuthorB-1
## sus.start.row and off.start.row should have the same configuration

    DALR.den.1 <- c(0)

    pb <- txtProgressBar(min = 1, max = nrow(DA.comps.author.indicies), style = 3)

    cat("...... DA comparisons: 1st partition")
    cat(" ......\n")

    for(DAcomp in 1 : nrow(DA.comps.author.indicies)) {

######################################################################
## MM should be repetition x * 2; NN should be [(repetition x * 2) - 1]
## if the repetition is 20, MM should be 40; NN should be 39  
## sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MM) - NN
    MMA1<-number.of.repeat*2
    NNA1<-(number.of.repeat*2)-1
    sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MMA1) - NNA1

######################################################################
## MM should be repetition x - 1
## sus.end.row <- sus.start.row + QQ
    QQ<-number.of.repeat - 1
    sus.end.row <- sus.start.row + QQ
    DA.sus.1 <- pop[sus.start.row : sus.end.row,]                 

######################################################################
## MM should be repetition x * 2; NN should be [(repetition x * 2) - 1]
## if the repetition is 20, MM should be 40; NN should be 39  
## sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MM) - NN
    MMB1<-number.of.repeat*2
    NNB1<-(number.of.repeat*2)-1  

    off.start.row <- (DA.comps.author.indicies[DAcomp,2] * MMB1) - NNB1
    QQ<-number.of.repeat - 1  
    off.end.row <- off.start.row + QQ
    DA.off.1 <- pop[off.start.row : off.end.row,] 

    control<-two.level.comparison.items(DA.off.1,variables)
    recovered<-two.level.comparison.items(DA.sus.1,variables)    

############################### back ground statistics ###############################
############################### back ground statistics ###############################
## cross-validated background statistics
## MM should be the repetition x 2
## NN should be (the repeition x 2) - 1  
## background.pop<-pop[c(-((DS.comps.author.indicies[DScomp,1]*MM)-NN):-(DS.comps.author.indicies[DScomp,1]*MM),
##                    -((DS.comps.author.indicies[DScomp,2]*MM)-NN):-(DS.comps.author.indicies[DScomp,2]*MM)),]

        MMP1<-number.of.repeat*2
        NNP1<-(number.of.repeat*2)-1
        background.pop<-pop[c(-((DA.comps.author.indicies[DAcomp,1]*MMP1)-NNP1):-(DA.comps.author.indicies[DAcomp,1]*MMP1),
                              -((DA.comps.author.indicies[DAcomp,2]*MMP1)-NNP1):-(DA.comps.author.indicies[DAcomp,2]*MMP1)),]

        # calculate the within and between group co-variances and means for each group
        UC<-two.level.components(background.pop,variables,grouping.variable)

############################### back ground statistics ###############################
############################### back ground statistics ###############################
      
        DALR.den.tmp.1<-suppressWarnings(two.level.density.LR(control,recovered,UC))
    
        DALR.den.1 <- c(DALR.den.1,DALR.den.tmp.1)

        current.da.comparison<-current.da.comparison + 1
        setTxtProgressBar(pb, DAcomp)
    }  

    close(pb)

    ## patch-up
    DALR.den.1 <- DALR.den.1[-1]
    log10.DALR.den.1 <- log10(as.matrix(DALR.den.1))

    ## compile matrix with author indicies and LRs ...
    DA.names.kden.LRs <- cbind(DA.comps.author.names,log10.DALR.den.1)

################################# PARTITION 2 #############################
################################# PARTITION 2 #############################
## authorA-1
## authorA-2
## authorB-1
## authorB-2
## PARTITION 2: AuthorA-2 vs. AuthorB-2
## sus.start.row and off.start.row should have the same configuration

    DALR.den.2 <- c()
    pb <- txtProgressBar(min = 1, max = nrow(DA.comps.author.indicies), style = 3)

    cat("...... DA comparisons: 2nd partition")
    cat(" ......\n")
                                               
    for(DAcomp in 1 : nrow(DA.comps.author.indicies)) {

######################################################################
## MM should be repetition x * 2; NN should be [repetition x - 1]
## if the repetition is 20, MM should be 40; NN should be 19  
## sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MM) - NN
        MMA2<-number.of.repeat*2
        NNA2<-number.of.repeat-1
        sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MMA2) - NNA2
  
######################################################################
## QQ should be repetition x - 1
## sus.end.row <- sus.start.row + QQ
        QQ<-number.of.repeat - 1
        sus.end.row <- sus.start.row + QQ

        DA.sus.2 <- pop[sus.start.row : sus.end.row,]
  
######################################################################
## MM should be repetition x * 2; NN should be [repetition x - 1]
## if the repetition is 20, MM should be 40; NN should be 19  
## sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MM) - NN
        MMB2<-number.of.repeat*2
        NNB2<-number.of.repeat-1  
        off.start.row <- (DA.comps.author.indicies[DAcomp,2] * MMB2) - NNB2
  
######################################################################
## QQ should be repetition x - 1
## sus.end.row <- sus.start.row + QQ
        QQ<-number.of.repeat - 1  
        off.end.row <- off.start.row + QQ

        DA.off.2 <- pop[off.start.row : off.end.row,] 

        control<-two.level.comparison.items(DA.off.2,variables)
        recovered<-two.level.comparison.items(DA.sus.2,variables)

############################### back ground statistics ###############################
############################### back ground statistics ###############################
## cross-validated background statistics
## MM should be the repetition x 2
## NN should be (the repeition x 2) - 1  
## background.pop<-pop[c(-((DS.comps.author.indicies[DScomp,1]*MM)-NN):-(DS.comps.author.indicies[DScomp,1]*MM),
##                    -((DS.comps.author.indicies[DScomp,2]*MM)-NN):-(DS.comps.author.indicies[DScomp,2]*MM)),]

        MMP2<-number.of.repeat*2
        NNP2<-(number.of.repeat*2)-1
        background.pop<-pop[c(-((DA.comps.author.indicies[DAcomp,1]*MMP2)-NNP2):-(DA.comps.author.indicies[DAcomp,1]*MMP2),
                              -((DA.comps.author.indicies[DAcomp,2]*MMP2)-NNP2):-(DA.comps.author.indicies[DAcomp,2]*MMP2)),]

        # calculate the within and between group co-variances and means for each group
        UC<-two.level.components(background.pop,variables,grouping.variable)

############################### back ground statistics ###############################
############################### back ground statistics ###############################

        DALR.den.tmp.2<-suppressWarnings(two.level.density.LR(control,recovered,UC))
        DALR.den.2 <- c(DALR.den.2,DALR.den.tmp.2)
        
        current.da.comparison<-current.da.comparison + 1
        setTxtProgressBar(pb, DAcomp)  
  }  

    close(pb)  

    log10.DALR.den.2 <- log10(as.matrix(DALR.den.2))

################### Assemble partitioned output for writing
    da.compared.authors<-cbind(rep(DA.comps.author.names[,1],each=4),
                               rep(DA.comps.author.names[,2],each=4))

    DALRs.4.parts <-cbind(log10.DALR.den.1,log10.DALR.den.2)

######################## a list of DALR as a string which may be useful for CLLR
######################## a list of DALR as a string which may be useful for CLLR

    compared.authors.dslrs <- rbind(cbind(DA.comps.author.names, DALRs.4.parts[,1]),
                                    cbind(DA.comps.author.names, DALRs.4.parts[,2]))

########################
########################

    DALRs.4.parts.names <- cbind(DA.comps.author.names, DALRs.4.parts)
    colnames(DALRs.4.parts.names) <- c("DA.sus", "DA.off", "partition 1", "partition 2")
    DALRs.non.part <-c(log10.DALR.den.1,log10.DALR.den.2) 

######################## LR dump file ########################
######################## LR dump file ########################

    ## change the following path
    ## change the following path
    write(t(same.author.den.logLRs), file= sa.out.file.name, ncolumns = 2)
    write(t(DALRs.4.parts.names), file= da.out.file.name, ncolumns = 4)

######################## END: LR dump file ########################
######################## END: LR dump file ########################

############## remove all objects ##############
############## remove all objects ##############
## Commnet our the following line if necessary
  
    rm(list=ls(all=TRUE))

### END OF FILE
  
}


non.cross.validated.mvlr.kden.calculation<-function(parameters,
                                                    parameter.in.file,
                                                    background.in.file,
                                                    sa.out.file.name,
                                                    da.out.file.name) {

#################################################
#################################################
#################################################
##
## This script was written by Shunichi Ishihara to be
## able to conduct an experiment in non-cross-validated
## manner.
##
#################################################
#################################################
#################################################

    ## convert variables to actual column numbers
    variables<-parameters + 3
    
    adjusted.variables<-(variables - 3)
    feature.legend<-paste("para", paste(adjusted.variables, sep="", collapse=""), sep="")

    pop <- read.table(parameter.in.file, header=TRUE)
    ## a list of unique author names  
    author.names <- unique(pop$authorindex)
    pop.no.individuals<- length(author.names)
  
    ########
    ########
    ## check whether all parameters have the same repetitions
    all.reps<-pop$repetition
    rep.max<-max(pop$repetition)
    rep.min<-min(pop$repetition)
    number.rep.max<-length(which(all.reps == rep.max))
    number.rep.min<-length(which(all.reps == rep.min))

    if (number.rep.max == number.rep.min) {
        number.of.repeat<-max(pop$repetition)
  
    } else {
        stop("all values are not in the same number")
  
    }
    ########
    ########

    grouping.variable <- 1

############################### back ground statistics
############################### back ground statistics
    ## non-cross-validated background statistics

    ## read in the background data
    background.pop <- read.table(background.in.file, header=TRUE)
    UC<-two.level.components(background.pop,variables,grouping.variable)
  
############################### back ground statistics
############################### back ground statistics

################## Same-author LRs ##################
################## Same-author LRs ##################
################## Same-author LRs ##################
################## Same-author LRs ##################

    SA <- 1 

    ## initialise matrices 
    SALR.den <- c(0)
    SALR.den.tmp <- c(0)
    pb <- txtProgressBar(min = 1, max = pop.no.individuals, style = 3)

    cat("...... SA comparisons")
    cat(" ......\n")
    
    for (SAcomp in 1 : pop.no.individuals) {
#### NOTE ################################
#### NOTE ################################
        # sus <- pop[SA:(SA + n), ] # specify n
        # how many repetition? If it is x, n should be x - 1
        SAZZ<-(number.of.repeat - 1)
        sus <- pop[SA:(SA + SAZZ), ]
##########################################
##########################################  
  
#### NOTE ################################
#### NOTE ################################
        # off <- pop[(SA+n):(SA+m),] # specifiy n and m
        # how many repetition? If it is x, n and m should be x and (x * 2) - 1
        SANN<-number.of.repeat
        SAMM<-(number.of.repeat*2)-1
        off <- pop[(SA+SANN):(SA+SAMM),]
##########################################
##########################################

#########################################
#########################################
        ## Similarity between offender and suspect samples
        control<-two.level.comparison.items(off,variables)
        recovered<-two.level.comparison.items(sus,variables)    

#########################################
#########################################

#--------------------------------------------------------------------
        SALR.den.tmp<-suppressWarnings(two.level.density.LR(control,recovered,UC))
        
        SALR.den <- c(SALR.den,SALR.den.tmp)

#### NOTE ################################
#### NOTE ################################
        # SA <- SA + n # specify n
        # how many repetition? If it is x, n should be x * 2
        SA <- SA + (number.of.repeat*2)

        setTxtProgressBar(pb, SAcomp)

    }

    close(pb)

    ## for some reason this has a lenght of one more than it should, with a first element as 0.
    ## patch-up for the moment:
    SALR.den <- SALR.den[-1]
    log10.SALR.den <- log10(as.matrix(SALR.den))

    ## assemble matrix of both LRs with author
    authors <-as.matrix(unique(author.names))
    same.author.den.logLRs <- cbind(authors,log10.SALR.den)

############### END: Same-author LRs ################
############### END: Same-author LRs ################
############### END: Same-author LRs ################
############### END: Same-author LRs ################

############### Different-author LRs ################
############### Different-author LRs ################
############### Different-author LRs ################
############### Different-author LRs ################

    ## Pre-process for DA LRs
    ## first compile matrix of DA author names/indicies for the different author comparisons.
    author.names <- as.matrix(author.names)

    no.author <- length(author.names)
    how.many <- no.author -1

    DA.sus.indicies <- c()
    DA.sus.names <- c()
  
    DA.off.indicies <- c()
    DA.off.names <- c()

    for(i in 1: (no.author - 1)) {

        DA.sus.index.tmp <- rep(i,how.many)
        DA.off.index.tmp <- seq(from= (i+1), to= no.author)

        DA.sus.indicies <- c(DA.sus.indicies,DA.sus.index.tmp)
        DA.off.indicies <- c(DA.off.indicies,DA.off.index.tmp)

        how.many <- how.many - 1

    } 
  
    DA.sus.names <- author.names[DA.sus.indicies]
    DA.off.names <- author.names[DA.off.indicies]

    DA.comps.author.indicies <- cbind(DA.sus.indicies,DA.off.indicies)

    DA.comps.author.names <- cbind(DA.sus.names,DA.off.names)

    da.no.comparisons<- nrow(DA.comps.author.names) * 4
    current.da.comparison<-0
    ## END: Pre-process for DA LRs

################################# PARTITION 1 #############################
################################# PARTITION 1 #############################
## authorA-1
## authorA-2
## authorB-1
## authorB-2
## PARTITION 1: AuthorA-1 vs. AuthorB-1
## sus.start.row and off.start.row should have the same configuration

    DALR.den.1 <- c(0)

    pb <- txtProgressBar(min = 1, max = nrow(DA.comps.author.indicies), style = 3)

    cat("...... DA comparisons: 1st partition")
    cat(" ......\n")

    for(DAcomp in 1 : nrow(DA.comps.author.indicies)) {

######################################################################
## MM should be repetition x * 2; NN should be [(repetition x * 2) - 1]
## if the repetition is 20, MM should be 40; NN should be 39  
## sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MM) - NN
        MMA1<-number.of.repeat*2
        NNA1<-(number.of.repeat*2)-1
        sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MMA1) - NNA1

######################################################################
## MM should be repetition x - 1
## sus.end.row <- sus.start.row + QQ
        QQ<-number.of.repeat - 1
        sus.end.row <- sus.start.row + QQ
        DA.sus.1 <- pop[sus.start.row : sus.end.row,]                 

######################################################################
## MM should be repetition x * 2; NN should be [(repetition x * 2) - 1]
## if the repetition is 20, MM should be 40; NN should be 39  
## sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MM) - NN
        MMB1<-number.of.repeat*2
        NNB1<-(number.of.repeat*2)-1  

        off.start.row <- (DA.comps.author.indicies[DAcomp,2] * MMB1) - NNB1
        QQ<-number.of.repeat - 1  
        off.end.row <- off.start.row + QQ
        DA.off.1 <- pop[off.start.row : off.end.row,] 

        control<-two.level.comparison.items(DA.off.1,variables)
        recovered<-two.level.comparison.items(DA.sus.1,variables)    

        DALR.den.tmp.1<-suppressWarnings(two.level.density.LR(control,recovered,UC))
        
        DALR.den.1 <- c(DALR.den.1,DALR.den.tmp.1)

        current.da.comparison<-current.da.comparison + 1

        setTxtProgressBar(pb, DAcomp)
      
    }  

    close(pb)

    ## patch-up
    DALR.den.1 <- DALR.den.1[-1]
    log10.DALR.den.1 <- log10(as.matrix(DALR.den.1))

    ## compile matrix with author indicies and LRs ...
    DA.names.kden.LRs <- cbind(DA.comps.author.names,log10.DALR.den.1)

################################# PARTITION 2 #############################
################################# PARTITION 2 #############################
## authorA-1
## authorA-2
## authorB-1
## authorB-2
## PARTITION 2: AuthorA-2 vs. AuthorB-2
## sus.start.row and off.start.row should have the same configuration

    DALR.den.2 <- c()

    pb <- txtProgressBar(min = 1, max = nrow(DA.comps.author.indicies), style = 3)

    cat("...... DA comparisons: 2nd partition")
    cat(" ......\n")

    for(DAcomp in 1 : nrow(DA.comps.author.indicies)) {

######################################################################
## MM should be repetition x * 2; NN should be [repetition x - 1]
## if the repetition is 20, MM should be 40; NN should be 19  
## sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MM) - NN
        MMA2<-number.of.repeat*2
        NNA2<-number.of.repeat-1
        sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MMA2) - NNA2
  
######################################################################
## QQ should be repetition x - 1
## sus.end.row <- sus.start.row + QQ
        QQ<-number.of.repeat - 1
        sus.end.row <- sus.start.row + QQ

        DA.sus.2 <- pop[sus.start.row : sus.end.row,]
  
######################################################################
## MM should be repetition x * 2; NN should be [repetition x - 1]
## if the repetition is 20, MM should be 40; NN should be 19  
## sus.start.row <- (DA.comps.author.indicies[DAcomp,1] * MM) - NN
        MMB2<-number.of.repeat*2
        NNB2<-number.of.repeat-1  
        off.start.row <- (DA.comps.author.indicies[DAcomp,2] * MMB2) - NNB2
  
######################################################################
## QQ should be repetition x - 1
## sus.end.row <- sus.start.row + QQ
        QQ<-number.of.repeat - 1  
        off.end.row <- off.start.row + QQ

        DA.off.2 <- pop[off.start.row : off.end.row,] 

        control<-two.level.comparison.items(DA.off.2,variables)
        recovered<-two.level.comparison.items(DA.sus.2,variables)    

        DALR.den.tmp.2<-suppressWarnings(two.level.density.LR(control,recovered,UC))
        DALR.den.2 <- c(DALR.den.2,DALR.den.tmp.2)

        current.da.comparison<-current.da.comparison + 1

        setTxtProgressBar(pb, DAcomp)
      
    }  

    close(pb)  
    log10.DALR.den.2 <- log10(as.matrix(DALR.den.2))

################### Assemble partitioned output for writing
    da.compared.authors<-cbind(rep(DA.comps.author.names[,1],each=4),
                               rep(DA.comps.author.names[,2],each=4))

    DALRs.4.parts <-cbind(log10.DALR.den.1,log10.DALR.den.2)

######################## a list of DALR as a string which may be useful for CLLR
######################## a list of DALR as a string which may be useful for CLLR

    compared.authors.dslrs <- rbind(cbind(DA.comps.author.names, DALRs.4.parts[,1]),
                                    cbind(DA.comps.author.names, DALRs.4.parts[,2]))

########################
########################

    DALRs.4.parts.names <- cbind(DA.comps.author.names, DALRs.4.parts)
    colnames(DALRs.4.parts.names) <- c("DA.sus", "DA.off", "partition 1", "partition 2")
    DALRs.non.part <-c(log10.DALR.den.1,log10.DALR.den.2) 

######################## LR dump file ########################
######################## LR dump file ########################

    ## change the following path
    ## change the following path
    write(t(same.author.den.logLRs), file= sa.out.file.name, ncolumns = 2)
    write(t(DALRs.4.parts.names), file= da.out.file.name, ncolumns = 4)

######################## END: LR dump file ########################
######################## END: LR dump file ########################

############## remove all objects ##############
############## remove all objects ##############
    ## Commnet our the following line if necessary
    
    rm(list=ls(all=TRUE))

### END OF FILE
  
}


  
