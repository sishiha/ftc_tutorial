### This is an R version of cg_dir(old_dir, grad, old_grad)

cg.dir<-function(old.dir, grad, old.grad) {
  
  g <- grad
  grad <- grad
  old.grad <- old.grad
  delta <- grad - old.grad
  den <- t(old.dir)%*%delta
  
  if (den==0) {
    dir <- g%*%0
  } else {
    
  # Hestenes-Stiefel
    beta <- as.vector((t(grad)%*%delta) / den)

  # Polak-Ribiere
  # beta = -grad'*(grad - old_grad) / (old_grad'*old_grad);

  # Fletcher-Reeves
  # beta = -(grad'*grad) / (old_grad'*old_grad);

    ### the following is originally a matrix product
    ### dir <- g - beta%*%old.dir
    dir <- g - beta*old.dir

  }

  return(dir)
}
