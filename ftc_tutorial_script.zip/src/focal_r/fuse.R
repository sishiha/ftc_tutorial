file.sources1 = list.files("./cllr",full.names=TRUE, pattern="*.[Rr]$")
file.sources2 = list.files("./fusion",full.names=TRUE, pattern="*.[Rr]$")
file.sources3 = list.files("./utils",full.names=TRUE, pattern="*.[Rr]$")
sapply(file.sources1,source,.GlobalEnv)
sapply(file.sources2,source,.GlobalEnv)
sapply(file.sources3,source,.GlobalEnv)

# source('./cllr/cllr.R')
# source('./cllr/cllr_min.R')
# source('./cllr/cllr_cal.R')
# source('./fusion/train_llr_fusion.R')
# source('./fusion/lin_fusion.R')

## test same-source (TSS) and different-source (TDS) LRs
TSS1 <- './data/test_sslr_cutoff_10_windowsize_5_shiftpercentage_100_para_5678910.txt'
TSS2 <- "./data/test_sslr_cutoff_10_windowsize_10_shiftpercentage_50_para_5678910.txt"
TSS3 <- "./data/test_sslr_cutoff_10_windowsize_5_shiftpercentage_33_para_5678910.txt"
TDS1 <- './data/test_dslr_cutoff_10_windowsize_5_shiftpercentage_100_para_5678910.txt'
TDS2 <- "./data/test_dslr_cutoff_10_windowsize_10_shiftpercentage_50_para_5678910.txt"
TDS3 <- "./data/test_dslr_cutoff_10_windowsize_5_shiftpercentage_33_para_5678910.txt"

## development ss and ds LRs
DSS1 <- './data/development_sslr_cutoff_10_windowsize_5_shiftpercentage_100_para_5678910.txt'
DSS2 <- "./data/development_sslr_cutoff_10_windowsize_10_shiftpercentage_50_para_5678910.txt"
DSS3 <- "./data/development_sslr_cutoff_10_windowsize_5_shiftpercentage_33_para_5678910.txt"
DDS1 <- './data/development_dslr_cutoff_10_windowsize_5_shiftpercentage_100_para_5678910.txt'
DDS2 <- "./data/development_dslr_cutoff_10_windowsize_10_shiftpercentage_50_para_5678910.txt"
DDS3 <- "./data/development_dslr_cutoff_10_windowsize_5_shiftpercentage_33_para_5678910.txt"

## write files for calibrated LRs
ssfilename = './dump/fused_ss_lrs.txt'
dsfilename = './dump/fused_ds_lrs.txt'
## write file for cllr values
filename = './dump/fused_cllr_min_cal.txt'

### test data ###
datatss1 <- read.table(TSS1,header=FALSE)
datatss2 <- read.table(TSS2,header=FALSE)
datatss3 <- read.table(TSS3,header=FALSE)
datatds1 <- read.table(TDS1,header=FALSE)　
datatds2 <- read.table(TDS2,header=FALSE)
datatds3 <- read.table(TDS3,header=FALSE)

tss1 <- as.vector(datatss1[,2])
tss2 <- as.vector(datatss2[,2])
tss3 <- as.vector(datatss3[,2])
logetss1 <- log(10^tss1)
logetss2 <- log(10^tss2)
logetss3 <- log(10^tss3)

tds11 <- as.vector(datatds1[,3])
tds12 <- as.vector(datatds1[,4])
tds21 <- as.vector(datatds2[,3])
tds22 <- as.vector(datatds2[,4])
tds31 <- as.vector(datatds3[,3])
tds32 <- as.vector(datatds3[,4])

tds1 = c(tds11, tds12)
logetds1 <- log(10^tds1)
tds2 = c(tds21, tds22)
logetds2 <- log(10^tds2)
tds3 = c(tds31, tds32)
logetds3 <- log(10^tds3)

logetss <- rbind(logetss1,logetss2,logetss3)
logetds <- rbind(logetds1,logetds2,logetds3)

### development data ###
datadss1 <- read.table(DSS1,header=FALSE)
datadss2 <- read.table(DSS2,header=FALSE)
datadss3 <- read.table(DSS3,header=FALSE)
datadds1 <- read.table(DDS1,header=FALSE)
datadds2 <- read.table(DDS2,header=FALSE)
datadds3 <- read.table(DDS3,header=FALSE)

dss1 <- as.vector(datadss1[,2])
dss2 <- as.vector(datadss2[,2])
dss3 <- as.vector(datadss3[,2])
logedss1 <- log(10^dss1)
logedss2 <- log(10^dss2)
logedss3 <- log(10^dss3)

dds11 <- as.vector(datadds1[,3])
dds12 <- as.vector(datadds1[,4])
dds21 <- as.vector(datadds2[,3])
dds22 <- as.vector(datadds2[,4])
dds31 <- as.vector(datadds3[,3])
dds32 <- as.vector(datadds3[,4])

dds1 = c(dds11, dds12)
dds2 = c(dds21, dds22)
dds3 = c(dds31, dds32)
logedds1 <- log(10^dds1)
logedds2 <- log(10^dds2)
logedds3 <- log(10^dds3)

logedss <- rbind(logedss1,logedss2,logedss3)
logedds <- rbind(logedds1,logedds2,logedds3)

w <- train.llr.fusion(logedss,logedds)
targetf <- lin.fusion(w, logetss)
nontargetf <- lin.fusion(w, logetds)

log10targetf <- as.vector(log10(exp(targetf)))
log10nontargetf <- as.vector(log10(exp(nontargetf)))

write(log10targetf, file=ssfilename, ncolumns = 1)
write(log10nontargetf, file=dsfilename, ncolumns = 1)

calib.cllr.value <- cllr(targetf,nontargetf)
calib.cllr.min.value <- cllr.min(targetf,nontargetf)
calib.cllr.cal.value <- cllr.cal(targetf,nontargetf)
calib.cllr.min.cal.values <- c(calib.cllr.value, calib.cllr.min.value, calib.cllr.cal.value)
print(calib.cllr.min.cal.values)

title.calib.cllr.min.cal.values<-(rbind(c("cllr","cllrmin","cllrcal"),calib.cllr.min.cal.values))

write.table(title.calib.cllr.min.cal.values,file=filename, sep=" ", quote=FALSE, row.names = FALSE, col.names = FALSE)

rm(list=ls(all=TRUE))

