# function neg_log_p = neglogsigmoid(log_odds);
# neg_log_p = NEGLOGSIGMOID(log_odds)
# This is mathematically equivalent to -log(sigmoid(log_odds)),
# but possibly numerically better.          

neglogsigmoid <- function (log.odds) {
  neg.log.p <- -log.odds
  e <- exp(-log.odds)
  f <- which(e < e + 1)
  neg.log.p[f] <- log(1+e[f])
  
}
