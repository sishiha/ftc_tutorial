### Draw a tippett plot

#################### plot only scores
plot.uncalib.tippett.plot<-function(uncalib.ssfile,
                                    uncalib.dsfile,
                                    tippett.plot.path
                                    ) {

  uncalib.ss.data<-read.table(uncalib.ssfile, header=FALSE)
  uncalib.ds.data<-read.table(uncalib.dsfile, header=FALSE)

  uncalib.ss.lrs<-uncalib.ss.data[,2]
  uncalib.ds.lrs<-c(uncalib.ds.data[,3], uncalib.ds.data[,4])

  writefile<-tippett.plot.path

  jpeg(writefile, width=480, quality = 100, height=480, pointsize=16)
  par(mar=c(4,4,1,1))
  plot(sort(uncalib.ss.lrs), seq(from=0, to =1, length =
                               length(uncalib.ss.lrs)), xlims<-c(-15,5),
       xlab = "Log10 Score", ylab = "Cumulative Proportion",
       type = "l", col = "black", lwd = 3, lty = "dotted")
  
  points(sort(uncalib.ds.lrs), seq(from=1, to =0, length = length(uncalib.ds.lrs)),
         type = "l", col = "gray", lwd = 3, lty = "dotted")

  # title(main = "Intrinsic 2-level kden log10MV Scores")

  grid(nx = NULL, col = "gray", lty = "dotted", lwd = 1)
  abline(v = 0)
  abline(h = 0.1 * 1:9, col="gray", lty = "dotted", lwd = 1)

  dev.off()

############## remove all assignments
  rm(list=ls(all=TRUE))
  
}

#################### plot calibrated LRs together with scores
plot.uncalib.calib.tippett.plot<-function(uncalib.ssfile,
                                          uncalib.dsfile,
                                          calib.ssfile,
                                          calib.dsfile,
                                          tippett.plot.path
                                          ) {

  uncalib.ss.data<-read.table(uncalib.ssfile, header=FALSE)
  uncalib.ds.data<-read.table(uncalib.dsfile, header=FALSE)

  calib.ss.data<-read.table(calib.ssfile, header=FALSE)
  calib.ds.data<-read.table(calib.dsfile, header=FALSE)

  calib.ss.lrs<-calib.ss.data[,1]
  calib.ds.lrs<-calib.ds.data[,1]

  uncalib.ss.lrs<-uncalib.ss.data[,2]
  uncalib.ds.lrs<-c(uncalib.ds.data[,3], uncalib.ds.data[,4])

  writefile<-tippett.plot.path
  jpeg(writefile, width=480, quality = 100, height=480, pointsize=16)
  par(mar=c(4,4,1,1))
  plot(sort(calib.ss.lrs), seq(from=0, to =1, length =
                               length(calib.ss.lrs)), xlims<-c(-15,5),
       xlab = "Log10 Likelihood Ratio", ylab = "Cumulative Proportion",
       type = "l", col = "black", lwd = 3)
  
  points(sort(calib.ds.lrs), seq(from=1, to =0, length = length(calib.ds.lrs)),
         type = "l", col = "gray", lwd = 3)
  points(sort(uncalib.ss.lrs), seq(from=0, to =1, length = length(uncalib.ss.lrs)),
         lty="dotted", type = "l", col = "black", lwd = 3)
  points(sort(uncalib.ds.lrs), seq(from=1, to =0, length = length(uncalib.ds.lrs)),
         lty="dotted", type = "l", col = "gray", lwd = 3)

  # title(main = "Intrinsic 2-level kden log10MVLR")

  grid(nx = NULL, col = "gray", lty = "dotted", lwd = 1)
  abline(v = 0)
  abline(h = 0.1 * 1:9, col="gray", lty = "dotted", lwd = 1)

  dev.off()

############## remove all assignments
  rm(list=ls(all=TRUE))
  
}


#################### plot only calibrated LRs 
plot.calib.tippett.plot<-function(calib.ssfile,
                                   calib.dsfile,
                                   tippett.plot.path
                                   ) {

  calib.ss.data<-read.table(calib.ssfile, header=FALSE)
  calib.ds.data<-read.table(calib.dsfile, header=FALSE)

  calib.ss.lrs<-calib.ss.data[,1]
  calib.ds.lrs<-calib.ds.data[,1]

  writefile<-tippett.plot.path
  jpeg(writefile, width=480, quality = 100, height=480, pointsize=16)
  par(mar=c(4,4,1,1))
  plot(sort(calib.ss.lrs), seq(from=0, to =1, length =
                               length(calib.ss.lrs)), xlims<-c(-15,5),
       xlab = "Log10 Likelihood Ratio", ylab = "Cumulative Proportion",
       type = "l", col = "black", lwd = 3)
  
  points(sort(calib.ds.lrs), seq(from=1, to =0, length = length(calib.ds.lrs)),
         type = "l", col = "gray", lwd = 3)

  # title(main = "Intrinsic 2-level kden log10MVLR")

  grid(nx = NULL, col = "gray", lty = "dotted", lwd = 1)
  abline(v = 0)
  abline(h = 0.1 * 1:9, col="gray", lty = "dotted", lwd = 1)

  dev.off()

############## remove all assignments
  rm(list=ls(all=TRUE))
  
}
