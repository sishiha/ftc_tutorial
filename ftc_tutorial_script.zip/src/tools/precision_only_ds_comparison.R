calculate.ci<-function(load.file.name.ss,
                       load.file.name.ds,
                       tippett.with.95CI,
                       # hist.95CI,
                       ci.value
                       ) {

## This script is an implementation of G. Morrison (2011) by S. Ishihara in R.
##
## Taking SS (sama source) and DS (different source) LRs as inputs, this script 
## calculated the 95% CI values from the DS LRs
## This script also plots the tippett plot of the SS and DS LR with 95% CI bands.
## This script also plots a hist gram of the differences of the two independent LRs

  LR.ds<-read.table(load.file.name.ds, header=FALSE)
  LR.ss<-read.table(load.file.name.ss, header=FALSE)

############################################3
######### 95% CI caliculation

  ## log_LR_ds = reshape(LR_ds, length(LR_ds)/4, 4)(:,3:4);
  log.LR.ds<-matrix(unlist(LR.ds), ncol=2)


  ## [mean_log_LR_ds, sortII_ds] = sort(mean(log_LR_ss, 2));
  mean.log.LR.ds<-apply(log.LR.ds, 1, mean)
  sortII.ds<-order(mean.log.LR.ds)
  sorted.mean.log.LR.ds<-sort(apply(log.LR.ds, 1, mean))

  ## log_LR_ds = log_LR_ds(sortII_ds,:);
  sorted.log.LR.ds<-log.LR.ds[sortII.ds,]

  ## dev_from_mean_log_LR_ds = log_LR_ds - repmat(mean_log_LR_ds, 1, 2)
  remap2x2<-cbind(sorted.mean.log.LR.ds, sorted.mean.log.LR.ds)
  # remap2x2<-cbind(sorted.mean.log.LR.ds, sorted.mean.log.LR.ds, sorted.mean.log.LR.ds, sorted.mean.log.LR.ds)

  dev.from.mean.log.LR.ds<-sorted.log.LR.ds - remap2x2

  alpha <- 0.05

  num.ds <- dim(log.LR.ds)[1]
  num.members.ds <- dim(log.LR.ds)[2]
  df = num.ds*(num.members.ds-1)

  sigma.hat.squared <- sum(dev.from.mean.log.LR.ds^2) / df;
  sigma.posterior = sqrt(sigma.hat.squared)
  CI.half<-qt(1-(alpha/2),df) * sigma.posterior

  write(CI.half, ci.value)

######### 95% CI calculation end
############################################3
  LR.ds<-unlist(LR.ds)
  LR.ss<-unlist(LR.ss)

### plot tippett plot with 95% CI band
###

  jpeg(tippett.with.95CI, width=480, quality = 100, height=480, pointsize=16)
  par(mar=c(4,4,1,1))
  plot(sort(LR.ss), seq(from=0, to =1, length =
                        length(LR.ss)), xlims<-c(-15,5), xlab = "Log10 Likelihood Ratio", ylab = "Cumulative Proportion",
       type = "l", col = "black", lwd = 3)
  # points(sort(LR.ss) - CI.half, seq(from=0, to =1, length = length(LR.ss)), type = "l", col = "red", lwd = 1.5, lty = "dotted")
  # points(sort(LR.ss) + CI.half, seq(from=0, to =1, length = length(LR.ss)), type = "l", col = "red", lwd = 1.5, lty = "dotted")

  points(sort(LR.ds), seq(from=1, to =0, length = length(LR.ds)), type = "l", col = "gray", lwd = 3)
  points(sort(LR.ds) - CI.half, seq(from=1, to =0, length = length(LR.ds)), type = "l", col = "gray", lwd = 2, lty = "dotted")
  points(sort(LR.ds) + CI.half, seq(from=1, to =0, length = length(LR.ds)), type = "l", col = "gray", lwd = 2, lty = "dotted")
  
  grid(nx = NULL, col = "gray", lty = "dotted", lwd = 1)
  abline(v = 0)
  abline(h = 0.1 * 1:9, col="gray", lty = "dotted", lwd = 1)

  dev.off()

### plot histogram of the differences of the independent LRs
###

  # jpeg(hist.95CI, width=480, quality = 75, height=480, pointsize=12)
  # par(mar=c(4,4,1,1))
  # hist(dev.from.mean.log.LR.ds,100,xlim=c(-6,6),ylim=c(0,100),col="lightblue",main=NULL,xlab="Deviation from mean log LR")
  # abline(v = 0, col="black", lwd=1.5)
  # abline(v = CI.half, col="red", lwd = 1)
  # abline(v = -CI.half, col="red", lwd = 1)
  # grid(nx = NULL, col = "gray", lty = "dotted", lwd = 1)

  # dev.off()
  
  return(CI.half)
############## remove all assignments
  rm(list=ls(all=TRUE))
  
}
