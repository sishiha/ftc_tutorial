###############
## created by Shunichi Ishihara, Tuesday, 11 October 2011
##
## get.closest.value is a function which returns the closest value
## to the specified value from the list
## get.closest value takes a list of numerical values (list)
## and a numerical value (value)

get.closest.value<-function(list, value) {
   index<-which(abs(list - value) == min(abs(list - value)))
   return(index)

}

###############

###############
## created by Shunichi Ishihara, Tuesday, 11 October 2011
##
## calc.eer is a function which take a list of SS LRs (SS.lrs.list)
## and that of DS LRs (DS.lrs.list) and
## returns the esimated Equal Error Rate (EER)
##
## get.closest.value is used in the calc.eer.

calc.eer<-function(SS.lrs.list, DS.lrs.list,filename) {
 sorted.SS.lrs<-sort(SS.lrs.list)
 sorted.DS.lrs<-sort(DS.lrs.list,decreasing=FALSE)
 length.SS.lrs<-length(sorted.SS.lrs)
 length.DS.lrs<-length(sorted.DS.lrs)
 ss.interval<-1 / (length.SS.lrs - 1)
 ds.interval<-1 / (length.DS.lrs - 1)

 density.list.ss<-NULL
 density.list.ds<-NULL 
 
 for (i in 0:(length.SS.lrs - 1)) {
   density.list.ss<-c(density.list.ss, (i * ss.interval))

 }

 for (i in 0:(length.DS.lrs - 1)) {
   density.list.ds<-c(density.list.ds, (i * ds.interval))

 }

 ss.lrs.density<-cbind(sorted.SS.lrs, sort(density.list.ss,decreasing=FALSE))
 ds.lrs.density<-cbind(sorted.DS.lrs, sort(density.list.ds,decreasing=TRUE))

 ## print(ds.lrs.density[,1])
 ## print(ds.lrs.density)

 difference.list<-NULL
 for (i in 1:length(ds.lrs.density[,1])) {
   ds.lr.value<-ds.lrs.density[i,1]
   ds.density.value<-ds.lrs.density[i,2]
   
   closet.ss.lr.value.index<-get.closest.value(ss.lrs.density[,1], ds.lr.value)
   # print(ds.lr.value)
   ss.closet.density.value<-ss.lrs.density[closet.ss.lr.value.index,2]

   density.difference<-abs(ds.density.value - ss.closet.density.value)
   difference.list<-c(difference.list,density.difference)
   
 }

 final.index<-which(difference.list == min(difference.list))
 target.ds.lr<-unname(ds.lrs.density[final.index,1])
 target.ss.lr.index<-get.closest.value(ss.lrs.density[,1], target.ds.lr)
 target.ss.lr<-ss.lrs.density[target.ss.lr.index,1]

 target.ds.density<-unname(ds.lrs.density[final.index,2])
 target.ss.density<-ss.lrs.density[target.ss.lr.index,2]

 estimated.eer<-((target.ds.density + target.ss.density) / 2)

 write.table(estimated.eer,file=filename, sep=" ", quote=FALSE, row.names = FALSE, col.names = FALSE)
 
 return(unname(estimated.eer))

}

###############



