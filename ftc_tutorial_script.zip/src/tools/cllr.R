# This is an implimentation of CLLR: Measure of goodness of log-likelihood-ratio in R based on
# the cllr.m provided by Niko Brummer
#
# CLLR: Measure of goodness of log-likelihood-ratio detection output. This measures both: 
#  - The quality of the score (over the whole DET curve), and
#  - The quality of the calibration 
#
#  c = CLLR(tar_llrs, nontar_llrs);
#
#  Input parameters:
#  tar_llrs: an array of log-likelihood-ratios for target trials
#  nontar_llrs: an array of log-likelihood-ratios for non-target trials
#
#  Note: 'log' in log-likelihood-ratio, denotes the logarithm (base 10).
#
#  Range: 0 <= c <= inf. 
#  Sense: small c is good, large c is bad. 
#  Reference: c = 1 = cllr(zeros(1,m),zeros(1,n)), m,n>0, is the performance of the 
#  reference system that does not process the input speech.
#  Note: Systems with bad calibration can do much worse than the reference system!
#
# Author: Niko Brummer, Spescom Datavoice.
# Disclaimer: This code is freely available for any non-commercial purpose, but the author and 
# his employer do not accept any responsibility for any consequences resulting from the use thereof.
# (E.g. getting an EER=50% at the NIST SRE.) 

# neglogsigmoid(log_odds)
# This is mathematically equivalent to -log(sigmoid(log_odds)), but possibly numerically better.  

neglogsigmoid <- function (log.odds) {
  neg.log.p <- -log.odds
  e <- exp(-log.odds)
  f <- which(e < e + 1)
  neg.log.p[f] <- log(1+e[f])
  
}

# cllr(tar_llrs, nontar_llrs)

cllr <- function (tar.llrs, nontar.llrs) {
  tar.llrs<-log(10^tar.llrs)
  nontar.llrs<-log(10^nontar.llrs)
  c1 <- mean(neglogsigmoid(tar.llrs))/log(2)
  c2 <- mean(neglogsigmoid(-nontar.llrs))/log(2)
  c <- (c1+c2)/2
  return(c)
  
}
